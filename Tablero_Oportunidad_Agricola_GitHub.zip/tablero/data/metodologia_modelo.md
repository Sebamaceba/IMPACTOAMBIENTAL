# Operación agrícola — Fase E

Las cifras vigentes están en `CAMBIOS_FASE_E.md`, la maestra, Pareto y Top 3. Los informes de fases anteriores son históricos. No se modifican las tablas pecuarias ni prediales.

- Oficial: `beneficio_sistema_observado`, equivalente a `beneficio_ha_anio` bajo la regla vigente y la asignación de maíz por sistema.
- Referencia recomendada PSA: `beneficio_referencia_2023_2025`. Es el promedio de márgenes de los años con precio anual: IPC a pesos de diciembre 2025, presupuesto/costo de 2025, producción, áreas e intensidad EVA de cada año. `anios_precio_referencia_psa` informa cuántos precios anuales participaron. Si falta costo, índice, base productiva o una homologación estable, queda pendiente.
- Aptitud: beneficio disponible y confianza B, o C sin `tipo_resultado='escenario'`. Los escenarios explícitos siguen excluidos aunque tengan un valor numérico. No representa una validación predial.
- Precio en finca: solo estructura; N0 = 1 para café pergamino, arroz paddy en molino y aceite de palma FOB. No se aplican factores a otros cultivos ni al beneficio oficial.

Ejecutar `ejecutar.py` desde la carpeta del proyecto. Por defecto prepara código y salidas en disco local junto a la SQLite configurada y publica las salidas en un lote tras terminar correctamente. `--forzar` invalida cachés; `--base` permite indicar otra SQLite local inicializada desde una copia válida. No se publica SQLite en Drive.

El cruce de precios persiste dentro de SQLite (`cache_cruce_*`). Se invalida por SHA-256 de EVA, SIPSA, fuentes sectoriales/gremiales, homologaciones, config y código del motor de precios; también verifica los registros SOAP y las entradas municipales. La restauración incluye precios por fila, catálogos y auditoría. La evidencia de panela se valida una vez por corrida.

`--reanudar-costos` permite continuar desde precios únicamente si todas las huellas del checkpoint coinciden. Rechaza el checkpoint si cambiaron los insumos. No vuelve a normalizar ni consolidar. Los tiempos distinguen reanudación, pasos previos y regeneraciones acotadas; la corrida continua inferior a cinco minutos quedó pendiente de medición integral por la interrupción documentada en E.

Los parámetros y fuentes están en `config.json`. Las nuevas fuentes se archivan en `Fuente de Datos/Fase E/`, con manifiesto de URL, consulta, página y SHA-256. `validacion_paginas_upra.csv` conserva pendientes por página; ahuyama publicada en 2025 no se relabela como costo 2025 si su vigencia es 2024. La URL original de COSTOS.xlsx permanece pendiente; el archivo local y la celda se verificaron.

La base local anterior a la publicación se conserva como respaldo `agro_psa_previo_fase_e_*.sqlite`. `validacion_fase_e.json` registra los controles y las huellas de tablas que debían permanecer intactas. `comparacion_cobertura_fase_e.csv` contiene todos los cultivos, incluidos los de cobertura cero, sin necesidad de abrir exportaciones grandes.
