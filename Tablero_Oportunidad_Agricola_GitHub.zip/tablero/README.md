# Territorio · Oportunidad agrícola en Colombia

Tablero estático HTML, CSS y JavaScript listo para GitHub Pages. Incluye una instantánea real de `SIPSA-Agro-PSA/agricola_nacional.csv`, sin modificar el modelo ni recalcular sus beneficios.

## Abrir localmente

Con Node.js disponible, ejecute desde esta carpeta:

```powershell
node serve.cjs
```

Abra http://127.0.0.1:8765 en el navegador. Mantenga abierta la terminal durante la consulta. No abra `index.html` por doble clic: el navegador restringe la lectura de JSON mediante `fetch` desde archivos locales.

## Publicar en GitHub

Suba **el contenido completo de esta carpeta** a la raíz del repositorio de su elección, incluyendo `data/` y `.github/`. Se incluye un workflow de GitHub Actions que publica el tablero en GitHub Pages al actualizar la rama `main` o ejecutarlo manualmente. Configure GitHub Pages para usar GitHub Actions en ese repositorio. Si su rama tiene otro nombre, ajuste `branches` en `.github/workflows/pages.yml`.

No se necesitan claves, base de datos, npm ni proceso de compilación. Los archivos originales del modelo, documentos de trabajo y SQLite no deben subirse: la exportación web ya contiene el detalle necesario. El paquete está preparado, pero esta entrega no crea ni publica un repositorio en su cuenta.

## Qué permite analizar

- Filtros por departamento, municipio (nombre o código DIVIPOLA), cultivo, año e indicador.
- Universo completo, aptos según el modelo PSA o sin escenarios explícitos.
- Indicadores ponderados por área, cobertura del cálculo y proporción de área con margen negativo.
- Pareto de contribuciones positivas, porcentaje acumulado y pérdidas por separado.
- Ranking departamental por margen/ha con cobertura visible.
- Mapa navegable de Colombia con puntos municipales: beneficio, participación por área y presencia productiva. La participación y presencia ignoran filtros de aptitud, porque describen producción registrada; el beneficio sí respeta esos filtros.
- Matriz departamento × cultivo: participación del área, hasta 10 cultivos con mayor área y siempre el cultivo seleccionado.
- Contexto histórico 2023–2025 del margen observado (pesos de cada año).
- Tabla paginada, búsqueda, orden y ficha de trazabilidad con fuentes, archivos, páginas, reglas y estados.
- CSV de todos los registros de la selección y búsqueda de tabla, con campos de trazabilidad e identificador SHA-256 de la maestra.
- La URL conserva los filtros; puede copiarla para compartir la misma vista.

## Interpretación y fórmulas

`beneficio_sistema_observado` es el indicador anual oficial, equivalente a `beneficio_ha_anio`. Corte oficial: 2025. Los años 2023 y 2024 son contexto.

`beneficio_referencia_2023_2025` es una referencia fija a pesos de diciembre de 2025: promedio de márgenes anuales con precios actualizados mediante IPC DANE, costos de 2025 y producción, áreas e intensidad EVA de cada año. Se consulta sobre los registros 2025, aunque la maestra lo repite en otros años. Al seleccionarlo se fija el año en 2025. No es una serie histórica a precios constantes.

Media ponderada = suma de beneficio × área física / suma de área física con beneficio numérico y área positiva.

Contribución estimada = beneficio/ha/año × área física del registro. El Pareto usa solo contribuciones positivas; las negativas se reportan por separado. No se suman márgenes por ha.

Cobertura = área física con beneficio calculado / área física de los registros filtrados. Los faltantes no se convierten a cero. El filtro de aptitud cambia tanto el numerador como el universo de cobertura: compare universos equivalentes.

Las áreas de cultivos son referencias productivas: pueden superponerse y no equivalen a superficie única de predios. La estimación agregada no es una valoración predial ni una tasa de retorno. Un margen negativo no prueba ausencia de producción ni implica automáticamente que su valor de compensación sea cero.

El mapa representa coordenadas DIVIPOLA municipales y no polígonos ni predios. El color corresponde al valor municipal agregado, no a interpolación espacial. No se inventan valores en municipios sin cálculo. En participación, el denominador es el área de todos los cultivos del municipio y año; la matriz usa el departamento como denominador.

La confianza y el tipo de resultado en tabla son las clasificaciones del registro fuente. Estas corresponden al resultado anual: para interpretar la referencia multianual revise su propio estado en la ficha. `anios_precio_referencia_psa` cuenta precios disponibles, no garantiza tres márgenes productivos completos. Los escenarios pueden tener un valor numérico sin ser aptos para PSA.

## Actualizar desde el modelo

La carpeta `tablero` debe estar junto a `SIPSA-Agro-PSA` y `Fuente de Datos`. Después de terminar una ejecución válida del modelo:

```powershell
node actualizar-datos.cjs
node verify.cjs
```

También se pueden indicar rutas absolutas:

```powershell
node actualizar-datos.cjs "RUTA/IMPACTO AMBIENTAL" "RUTA/tablero"
```

Publique nuevamente **todos** los archivos de `data/` junto al código. Es una instantánea; el navegador no lee directamente Google Drive ni se actualiza en tiempo real. El generador no ejecuta el modelo ni usa respaldos anteriores.

## Estructura y trazabilidad

- `index.html`, `styles.css`, `app.js`: interfaz.
- `core.js`: agregaciones compartidas entre interfaz y controles de verificación.
- `data/index.json`: índice compacto y metadatos; 48.689 registros y 1.101 municipios en esta entrega, años 2023–2025. Aproximadamente 3,4 MB.
- `data/detalle/CODIGO.json`: campos de evidencia por municipio, cargados a demanda.
- `data/corte_oficial_agro.json`, `data/config_modelo.json`, `data/metodologia_modelo.md`: definición del corte, parámetros y metodología fuente.
- `actualizar-datos.cjs`: generador sin dependencias externas.
- `verify.cjs`: comprueba ponderación, faltantes, negativos, unicidad y equivalencia de cada registro entre índice y ficha.
- `VALIDACION.json`: resultados de verificación de esta entrega.

La maestra se identifica por SHA-256 y fecha de modificación en los metadatos y el tablero. `id_tablero` corresponde al número de registro de datos de la maestra, empezando en 1; `fila_csv_origen` añade el encabezado. Es la posición lógica del registro CSV (un campo entre comillas podría contener saltos de línea), no necesariamente la línea física en un editor.

Se omiten del tablero los registros sin código de cultivo; se conservan registros de cultivos sin beneficio o sin área. Una comparación municipal debe considerar la cobertura y mezcla de cultivos.

## Dependencias y verificación

Leaflet 1.9.4 y sus estilos se cargan desde unpkg; cartografía base de OpenStreetMap; tipografías de Google Fonts con alternativas locales. Necesitan internet. Si Leaflet falla, el resto del tablero sigue funcionando con un mensaje en el mapa. La ficha enlaza archivos por nombre como referencia; los PDF originales no se incluyen. Las URL de fuente disponibles abren el documento correspondiente.

Se verificaron cálculos y correspondencia de los 48.689 registros, carga en navegador, filtros de indicador/departamento/municipio, detalle y descarga CSV. El diseño incorpora puntos de adaptación a pantallas pequeñas; no se ha completado una prueba exhaustiva en dispositivos físicos ni de accesibilidad.

