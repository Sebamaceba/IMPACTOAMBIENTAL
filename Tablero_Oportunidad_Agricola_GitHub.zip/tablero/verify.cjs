const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),{stats}=require('./core.js');
const {meta,rows}=JSON.parse(fs.readFileSync(path.join(__dirname,'data/index.json'),'utf8'));
assert.equal(rows.length,meta.rows);assert.equal(new Set(rows.map(r=>r[0])).size,rows.length);
let sample=[{area:2,annual:10,mun:'a',crop:'x'},{area:1,annual:-4,mun:'b',crop:'x'},{area:3,annual:null,mun:'c',crop:'y'}],s=stats(sample,'annual');assert.equal(s.mean,16/3);assert.equal(s.coverage,.5);assert.equal(s.negativeArea,1);assert.equal(s.positive,20);assert.equal(stats([],'annual').mean,null);
let detailCount=0,files=fs.readdirSync(path.join(__dirname,'data/detalle'));const detailMap=new Map();for(const file of files){const detail=JSON.parse(fs.readFileSync(path.join(__dirname,'data/detalle',file),'utf8'));detailCount+=detail.length;for(const row of detail){assert.equal(row.length,meta.fields.length+1);detailMap.set(row[0],row);}}
assert.equal(detailCount,rows.length);
for(const r of rows){const d=detailMap.get(r[0]);assert(d);assert.equal(d[3],meta.dict[r[3]]);assert.equal(d[13],r[9]);assert.equal(d[14],r[10]);assert.equal(d[9],r[8]);}
const decoded=rows.map(r=>({id:r[0],area:r[8],annual:r[9],reference:r[10],mun:meta.dict[r[3]],crop:meta.dict[r[6]],year:r[5]}));
const annual=stats(decoded.filter(r=>r.year===2025),'annual'),reference=stats(decoded.filter(r=>r.year===2025),'reference');
const maxFile=Math.max(...files.map(f=>fs.statSync(path.join(__dirname,'data/detalle',f)).size));assert(maxFile<100e6);
console.log(JSON.stringify({checks:'OK: medias, faltantes, negativos, unicidad, equivalencia de cada registro y fichas',rows:rows.length,municipalities:files.length,annual2025:annual,reference2025:reference,largestDetailBytes:maxFile},null,2));
