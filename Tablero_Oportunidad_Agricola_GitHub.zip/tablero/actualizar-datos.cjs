const fs=require('fs'),path=require('path'),crypto=require('crypto');
const root=process.argv[2]||path.dirname(__dirname),out=process.argv[3]||__dirname;
function csv(s,sep){let rows=[],r=[],v='',q=false;for(let i=0;i<s.length;i++){let c=s[i];if(c==='"'){if(q&&s[i+1]==='"'){v+='"';i++;}else q=!q;}else if(c===sep&&!q){r.push(v);v='';}else if((c==='\n'||c==='\r')&&!q){if(c==='\r'&&s[i+1]==='\n')i++;r.push(v);if(r.some(Boolean))rows.push(r);r=[];v='';}else v+=c;}if(v||r.length){r.push(v);rows.push(r);}let h=rows.shift().map(x=>x.replace(/^\uFEFF/,''));return rows.map(r=>Object.fromEntries(h.map((k,i)=>[k,r[i]||''])));}
const src=path.join(root,'SIPSA-Agro-PSA','agricola_nacional.csv'),buf=fs.readFileSync(src),rows=csv(buf.toString('utf8'),';');
const geo=csv(fs.readFileSync(path.join(root,'Fuente de Datos','DIVIPOLA_DANE.csv'),'utf8'),',');
const coords=Object.fromEntries(geo.map(r=>[r['Código Municipio'],[Number(r.Latitud.replace(',','.')),Number(r.longitud.replace(',','.'))]]));
const fields=['departamento','nombre_departamento','municipio','nombre_municipio','anio','codigo_cultivo','cultivo','estado_fisico','area_fisica_ha','sembrada_ha','cosechada_ha','produccion_t','beneficio_sistema_observado','beneficio_referencia_2023_2025','anios_precio_referencia_psa','apto_referencia_psa','confianza','tipo_resultado','estado_sistema_observado','estado_referencia_psa','base_area_beneficio','precio_referencia','fuente_precio','archivo_fuente_precio','fuente_costo','costo_url_fuente','costo_archivo_fuente','costo_pagina_fuente','periodo_costo','observacion_beneficio','observacion_referencia_psa','observacion_confianza','estado_aptitud_psa','observacion_aptitud_psa','costo_metodo_actualizacion','intensidad_uso','ciclos_max_aplicado','ingreso_cop_ha_base','costo_aplicado_cop_ha_base','ficha_costo','incluido_corte_agro','rol_periodo'];
const numeric=new Set([4,8,9,10,11,12,13,14,15,21,35,36,37,38,40]);
fs.mkdirSync(path.join(out,'data','detalle'),{recursive:true});
let dict=[],di=new Map();function intern(x){if(!di.has(x)){di.set(x,dict.length);dict.push(x);}return di.get(x);}
const compact=[],details={};let count=0;
for(const [sourceIndex,r] of rows.entries()){if(!r.codigo_cultivo)continue;count++;const id=sourceIndex+1,a=fields.map((f,i)=>numeric.has(i)?(r[f]===''?null:Number(r[f])):r[f]);
if(a.some((x,i)=>numeric.has(i)&&x!==null&&!Number.isFinite(x)))throw Error('Número inválido '+id);
(details[r.municipio]??=[]).push([id,...a]);
compact.push([id,intern(r.departamento),intern(r.nombre_departamento),intern(r.municipio),intern(r.nombre_municipio),a[4],intern(r.codigo_cultivo),intern(r.cultivo),a[8],a[12],a[13],a[14],a[15],intern(r.confianza),intern(r.tipo_resultado),intern(r.estado_fisico),a[40]]);}
for(const [id,d] of Object.entries(details))fs.writeFileSync(path.join(out,'data','detalle',id+'.json'),JSON.stringify(d));
const meta={source:'agricola_nacional.csv',sha256:crypto.createHash('sha256').update(buf).digest('hex'),generated:new Date().toISOString(),sourceModified:fs.statSync(src).mtime.toISOString(),rows:count,fields,coords,dict,years:[...new Set(compact.map(r=>r[5]))].sort(),method:fs.readFileSync(path.join(root,'SIPSA-Agro-PSA','README_FASE_E.md'),'utf8')};
fs.writeFileSync(path.join(out,'data','index.json'),JSON.stringify({meta,rows:compact}));
fs.copyFileSync(path.join(root,'SIPSA-Agro-PSA','corte_oficial_agro.json'),path.join(out,'data','corte_oficial_agro.json'));
fs.copyFileSync(path.join(root,'SIPSA-Agro-PSA','config.json'),path.join(out,'data','config_modelo.json'));
fs.copyFileSync(path.join(root,'SIPSA-Agro-PSA','README_FASE_E.md'),path.join(out,'data','metodologia_modelo.md'));
console.log(JSON.stringify({rows:count,municipalities:Object.keys(details).length,years:meta.years,indexMB:fs.statSync(path.join(out,'data','index.json')).size/1e6,sha256:meta.sha256}));
